To solve this assignment I used the following:

Python 3.4
Anaconda
SQLite3

The following packages was used with Python:

numpy
sqlite3
matplotlib


The scripts were compiled using the Python build in compiler.


----
Jonathan Schr�der Holm Hansen, fdg890
Datamining final assignment